function getMaxPairs(noOfWashes, cleanPile, dirtyPile) {
  // Your solution goes here.
}

module.exports = getMaxPairs;
