/**
 * This is the entry point to the program
 *
 * @param {any} input Array of student objects
 */
function classifier(input) {}

module.exports = classifier;
